<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PengambilanMkDos extends Model
{
    use HasFactory;
    protected $table = 'pengambilan_mata_kuliah_dos';
}
