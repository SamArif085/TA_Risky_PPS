<div class="container-fluid page-header py-6 my-6 mt-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center">
        <h1 class="display-4 text-white animated slideInDown mb-4"><?php echo e($title); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                <li class="breadcrumb-item text-primary active" aria-current="page"><?php echo e($title); ?></li>
            </ol>
        </nav>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-12">
            <center class="mb-5">
                <h1>Data Taruna Aktif Program Studi Teknik Navigasi Udara</h1>
            </center>
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <?php $__currentLoopData = $dataPerAngkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angkatanId => $tarunas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($tarunas) > 0): ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="tab-<?php echo e($angkatanId); ?>"
                        data-bs-toggle="tab" data-bs-target="#angkatan-<?php echo e($angkatanId); ?>" type="button" role="tab"
                        aria-controls="angkatan-<?php echo e($angkatanId); ?>"
                        aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"><?php echo e($tarunas[0]->angkatan->angkatan); ?></button>
                </li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabContent">
                <?php $__currentLoopData = $dataPerAngkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angkatan => $tarunas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="angkatan-<?php echo e($angkatan); ?>"
                    role="tabpanel" aria-labelledby="tab-<?php echo e($angkatan); ?>">
                    <div class="row">
                        <?php $__currentLoopData = $tarunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taruna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-text"><?php echo e($taruna->keterangan); ?></h4>
                                    <div class="col-12">
                                        <img src="<?php echo e(asset($tarunas[0]->file)); ?>" class="img-fluid mb-4"
                                            alt="Full-width image">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/user/page/data_taruna.blade.php ENDPATH**/ ?>