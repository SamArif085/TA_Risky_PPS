<div class="container-fluid page-header py-6 my-6 mt-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center">
        <h1 class="display-4 text-white animated slideInDown mb-4"><?php echo e(isset($title) ? $title : ''); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                <li class="breadcrumb-item text-primary active" aria-current="page"><?php echo e(isset($title) ? $title : ''); ?>

                </li>
            </ol>
        </nav>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-12">
            <center>
                <h4 class="mb-3">Penelitian</h4>
            </center>
            <div class="card">
                <div class="card-header">Pengertian</div>
                <div class="card-body">
                    <p>
                        Penelitian adalah suatu proses penyelidikan yang ilmiah melalui pengumpulan, pengolahan,
                        analisis dan penyimpulan data berdasarkan pendekatan, metode dan teknik tertentu untuk menjawab
                        suatu permasalahan
                    </p>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-12">
            <center>
                <h4 class="mb-3 mt-4">Daftar Penelitian</h4>
            </center>
            <table class="table table-bordered">
                <thead class="text-center">
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama Dosen</th>
                        <th scope="col">Judul Artikel yang Disitasi (Jurnal/Buku, Volume, Tahun, Nomor, Halaman)</th>
                        <th scope="col">Jumlah Sitasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item['dosen']['nama_dosen']); ?></td>
                        <td><?php echo e($item['judul']); ?></td>
                        <td class="text-center"><?php echo e($item['jumlah']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/user/page/penelitian.blade.php ENDPATH**/ ?>