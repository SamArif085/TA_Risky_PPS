<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="font-weight-bold mb-0"><?php echo e($subtitle); ?></h4>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Form <?php echo e($judulForm); ?></h4>
                <form class="forms-sample"
                    action="<?php echo e($judulForm == 'Tambah' ? route($routeName . '.submit') : route($routeName . '.submit', $data->id)); ?>"
                    method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="id" value="<?php echo e($judulForm == 'Tambah' ? '' : $data->id); ?>">
                    <div class="form-group mb-3">
                        <label for="Kategori">Angkatan</label>
                        <select name="angkatan" id="angkatan" class="select2 form-control" data-allow-clear="true"
                            required>
                            <option value="">Pilih Angkatan</option>
                            <?php $__currentLoopData = $dataAngkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item['id']); ?>" <?php echo e($judulForm=='Tambah' ? '' :
                                ($data['Angkatan']['id']==$item['id'] ? 'selected' : '' )); ?>>
                                <?php echo e($item['angkatan']); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group mb-3">
                        <label for="Kategori">Kategori</label>
                        <select class="form-control" name="kategori" id="kategori" required>
                            <option value="" <?php echo e(empty($data) ? 'selected' : ''); ?>>Pilih</option>
                            <option value="1" <?php echo e((!empty($data) && isset($data['kategori']) && $data['kategori']==1)
                                ? 'selected' : ''); ?>>Laporan Tugas Akhir</option>
                            <option value="2" <?php echo e((!empty($data) && isset($data['kategori']) && $data['kategori']==2)
                                ? 'selected' : ''); ?>>Laporan OJT</option>
                        </select>
                    </div>
                    <div class="form-group mb-3">
                        <label for="Nama">Nama</label>
                        <input type="text" class="form-control" id="namas" placeholder="Nama" name="nama"
                            value="<?php echo e($judulForm == 'Tambah' ? '' : $data->nama); ?>" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="judul">Judul</label>
                        <textarea class="form-control" id="judul" name="judul" rows="5" placeholder="Judul Artikel"
                            required><?php echo e($judulForm == 'Tambah' ? '' : $data->judul); ?></textarea>
                    </div>
                    <div class="form-group mb-3">
                        <label for="judul">Tahun</label>
                        <input type="text" class="form-control" id="year" placeholder="Nama" name="year"
                            value="<?php echo e($judulForm == 'Tambah' ? '' : $data->tahun); ?>" required>
                    </div>
                    <div class="form-group mb-3">
                        <label>File upload</label>
                        <input type="file" id="file" name="file" class="form-control-file">
                        <div class="form-control mt-3"><?php if(isset($judulForm) && $judulForm == 'Edit'): ?>
                            <?php echo e($data->file); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                    <a href="<?php echo e(route($routeName . '')); ?>" class="btn btn-light">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/admin/page/research/laporan_ta_ojt/form.blade.php ENDPATH**/ ?>