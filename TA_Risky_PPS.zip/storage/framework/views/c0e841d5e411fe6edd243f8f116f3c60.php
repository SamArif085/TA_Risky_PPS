<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="font-weight-bold mb-0"><?php echo e($subtitle); ?></h4>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12 mb-4 ">
        <div>
            <a href="<?php echo e(route($routeName . '.add')); ?>" class="btn btn-primary float-right"><i class="ti-plus"></i>
                Tambah</a>
        </div>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive pt-3">
                    <table class="table table-bordered" id="data-table">
                        <thead class="text-center">
                            <tr>
                                <th scope="col" rowspan="2">No</th>
                                <th scope="col" rowspan="2">Angkatan</th>
                                <th scope="col" rowspan="2">Kegiatan</th>
                                <th scope="col" colspan="2">jadwal Pelaksanaan</th>
                                <th scope="col" rowspan="2">Semester </th>
                                <th scope="col" rowspan="2">Semester Ganjil atau Genap</th>
                                <th scope="col" rowspan="2">Action</th>
                            </tr>
                            <tr>
                                <th scope="col">Awal</th>
                                <th scope="col">Akhir</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item['angkatan']['angkatan']); ?></td>
                                <td><?php echo e($item['kegiatan']); ?></td>
                                <td><?php echo e($item['tgl_jadwal_awal']); ?></td>
                                <td><?php echo e($item['tgl_jadwal_akhir']); ?></td>
                                <td><?php echo e($item['semester']['semester']); ?></td>
                                <td>
                                    <?php if($item['ganjil_genap'] == 1): ?>
                                    Ganjil
                                    <?php elseif($item['ganjil_genap'] == 2): ?>
                                    Genap
                                    <?php else: ?>
                                    -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route($routeName. '.edit', $item['id'])); ?>"
                                        class="btn btn-sm btn-primary"><i class="ti-pencil"></i>
                                    </a>
                                    <button class="btn btn-sm btn-danger"
                                        onclick="AddKurikulum.delete(<?php echo e($item['id']); ?>)"><i class="ti-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
<script>
    let AddKurikulum = {
            delete: (id) => {
                let url = '<?php echo e(route($routeName . '.delete')); ?>';
                Swal.fire({
                    title: "Konfirmasi Hapus ?",
                    text: `Apakah Anda yakin akan menghapus data ini ?`,
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Ya, Hapus!",
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            type: "POST",
                            url: url,
                            data: {
                                id: id,
                            },
                            success: function(response) {
                                if (response.code == 200) {
                                    Swal.fire({
                                        icon: "success",
                                        title: "Berhasil",
                                        text: response.message,
                                    }).then((result) => {
                                        if (result.isConfirmed) {
                                            location.reload();
                                        }
                                    });
                                } else {
                                    Swal.fire({
                                        icon: "error",
                                        title: "Gagal",
                                        text: response.message,
                                    }).then((result) => {
                                        if (result.isConfirmed) {
                                            location.reload();
                                        }
                                    });
                                }
                            },
                        });
                    }
                });
            },
        };
        $(document).ready(function() {
            $('#data-table').DataTable();
        });
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/admin/page/akademik/kalender/index.blade.php ENDPATH**/ ?>