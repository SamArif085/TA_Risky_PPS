<div class="container-fluid page-header py-6 my-6 mt-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center">
        <h1 class="display-4 text-white animated slideInDown mb-4"><?php echo e($title); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                <li class="breadcrumb-item text-primary active" aria-current="page"><?php echo e($title); ?></li>
            </ol>
        </nav>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-12">
            <center>
                <h4>Video Profile Prodi TNU</h4>
            </center>
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo e($key == 0 ? 'active' : ''); ?>" id="tab-<?php echo e($video->id); ?>"
                        data-bs-toggle="tab" data-bs-target="#video-<?php echo e($video->id); ?>" type="button" role="tab"
                        aria-controls="video-<?php echo e($video->id); ?>" aria-selected="<?php echo e($key == 0 ? 'true' : 'false'); ?>"><?php echo e($video->judul_video); ?></button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabContent">
                <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade<?php echo e($key == 0 ? ' show active' : ''); ?>" id="video-<?php echo e($video->id); ?>"
                    role="tabpanel" aria-labelledby="tab-<?php echo e($video->id); ?>">
                    <?php if($video->video_id): ?>
                    <div class="ratio ratio-16x9">
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo e($video->video_id); ?>"
                            title="<?php echo e($video->judul_video); ?>" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen>
                        </iframe>
                    </div>
                    <?php else: ?>
                    <p>Invalid video URL</p>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/user/page/video_profile.blade.php ENDPATH**/ ?>