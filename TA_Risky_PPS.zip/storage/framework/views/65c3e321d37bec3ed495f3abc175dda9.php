<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="font-weight-bold mb-0"><?php echo e($subtitle); ?></h4>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Form <?php echo e($judulForm); ?></h4>
                <form class="forms-sample"
                    action="<?php echo e($judulForm == 'Tambah' ? route($routeName . '.submit') : route($routeName . '.submit', $data->id)); ?>"
                    method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group mb-3">
                                <label for="angkatan">Angkatan</label>
                                <select name="angkatan" id="angkatan" class="select2 form-control"
                                    data-allow-clear="true">
                                    <option value="">Pilih Angkatan</option>
                                    <?php $__currentLoopData = $dataAngkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item['id']); ?>" <?php echo e($judulForm=='Tambah' ? '' :
                                        ($data['angkatan']['angkatan']==$item['angkatan'] ? 'selected' : '' )); ?>>
                                        <?php echo e($item['angkatan']); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <input type="hidden" name="id" id="id"
                                value="<?php echo e($judulForm == 'Tambah' ? '' : $data->id); ?>">
                            <div class="form-group mb-3">
                                <label for="kegiatan">Kegiatan</label>
                                <input type="text" class="form-control" id="kegiatan" placeholder="Kegiatan"
                                    name="kegiatan" value="<?php echo e($judulForm == 'Tambah' ? '' : $data->kegiatan); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group mb-3">
                                <label for="tgl_jadwal_awal">Tanggal Awal</label>
                                <input type="date" class="form-control" id="tgl_jadwal_awal" placeholder="Tanggal Awal"
                                    name="tgl_jadwal_awal"
                                    value="<?php echo e($judulForm == 'Tambah' ? '' : $data->tgl_jadwal_awal); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group mb-3">
                                <label for="tgl_jadwal_akhir">Tanggal Akhir</label>
                                <input type="date" class="form-control" id="tgl_jadwal_akhir"
                                    placeholder="Tanggal Akhir" name="tgl_jadwal_akhir"
                                    value="<?php echo e($judulForm == 'Tambah' ? '' : $data->tgl_jadwal_akhir); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group mb-3">
                                <label for="Ganjul atau Genap">Semester Ganjil atau Genap</label>
                                <select name="ganjil_genap" id="ganjil_genap" class="select2 form-control"
                                    data-allow-clear="true">
                                    <option value="">Pilih</option>
                                    <option value="1" <?php echo e(isset($data['ganjil_genap']) && $data['ganjil_genap']==1
                                        ? 'selected' : ''); ?>>Ganjil</option>
                                    <option value="2" <?php echo e(isset($data['ganjil_genap']) && $data['ganjil_genap']==2
                                        ? 'selected' : ''); ?>>Genap</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group mb-3">
                                <label for="catatan">Semester</label>
                                <select name="semester" id="semester" class="select2 form-control"
                                    data-allow-clear="true">
                                    <option value="">Pilih</option>
                                    <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item['id']); ?>" <?php echo e($judulForm=='Tambah' ? '' : ($item['id']
                                        ? 'selected' : '' )); ?>>
                                        <?php echo e($item['semester']); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                    <a href="<?php echo e(route($routeName . '')); ?>" class="btn btn-light">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/admin/page/akademik/kalender/form.blade.php ENDPATH**/ ?>