<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="font-weight-bold mb-0"><?php echo e($subtitle); ?></h4>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Form <?php echo e($judulForm); ?></h4>
                <form class="forms-sample"
                    action="<?php echo e($judulForm == 'Tambah' ? route($routeName . '.submit') : route($routeName . '.submit', $data->id)); ?>"
                    method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="id"
                        value="<?php echo e($judulForm == 'Tambah' ? '' : $data->id); ?>">
                    <div class="form-group mb-3">
                        <label for="nama">Nama</label>
                        <input type="text" class="form-control" id="nama" placeholder="Nama" name="nama"
                            value="<?php echo e($judulForm == 'Tambah' ? '' : $data->nama); ?>">
                    </div>
                    <div class="form-group mb-3">
                        <label>File upload</label>
                        <input type="file" id="file" name="file" class="form-control-file">
                        
                        <?php if(isset($judulForm) && $judulForm == 'Edit'): ?>
                            <img src="<?php echo e(isset($data->file) ? asset($data->file) : ''); ?>" class="img-thumbnail mt-2"
                                width="50%">
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                    <a href="<?php echo e(route($routeName . '')); ?>" class="btn btn-light">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/admin/page/profile/sertifikasi/form.blade.php ENDPATH**/ ?>