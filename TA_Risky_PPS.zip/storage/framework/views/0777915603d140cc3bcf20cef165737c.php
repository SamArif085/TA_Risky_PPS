<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="font-weight-bold mb-0"><?php echo e($subtitle); ?></h4>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive pt-3">
                    
                    <table class="table table-bordered" id="data-table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Semester</th>
                                <th>Matkul</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item['angkatan'] == Auth::user()->angkatan): ?>
                            <?php $__currentLoopData = $item['matkul']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $isDisabled = false;
                            foreach ($riwayat_absen as $item1) {
                            if ($item1['matkul']['mata_kuliah'] == $items['mata_kuliah']) {
                            $isDisabled = true;
                            break;
                            }
                            }
                            ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item['semester']['semester']); ?></td>
                                <td><?php echo e($items['mata_kuliah']); ?></td>
                                <td>
                                    <?php if($isDisabled): ?>
                                    <button class="btn btn-sm btn-primary" disabled>
                                        <i class="ti-pencil"></i> Presensi
                                    </button>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('presensi_mhs', ['kode_matkul' => $items['kode'], 'angkatan' => $item['angkatan'], 'semester' => $item['semester']['semester']])); ?>"
                                        class="btn btn-sm btn-primary"><i class="ti-pencil"></i> Presensi
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/admin/page/matkul_mhs/index.blade.php ENDPATH**/ ?>