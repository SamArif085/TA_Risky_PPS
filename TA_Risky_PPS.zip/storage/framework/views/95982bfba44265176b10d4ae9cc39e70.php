<script src="<?php echo e(asset('utils/jquery.js')); ?>"></script>


<script src="<?php echo e(asset('utils/select2/select2.js')); ?>"></script>
<script src="<?php echo e(asset('utils/quill/quill.js')); ?>"></script>
<script src="<?php echo e(asset('utils/bootbox/bootbox.js')); ?>"></script>
<script src="<?php echo e(asset('utils/message.js')); ?>"></script>
<script src="<?php echo e(asset('utils/validation.js')); ?>"></script>
<script src="<?php echo e(asset('utils/flatpickr/flatpickr.js')); ?>"></script>





<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"
    integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


<?php if(session()->has('success')): ?>
<script>
    toastr.success(`<?php echo e(session('success')); ?>`);
</script>
<?php endif; ?>
<?php if(session()->has('error')): ?>
<script>
    toastr.error(`<?php echo e(session('error')); ?>`);
        console.log(`<?php echo e(session('error')); ?>`);
</script>
<?php endif; ?>
<?php if(count($errors) > 0): ?>
<script>
    toastr.error(`<?php echo e($errors->first()); ?>`);
</script>
<?php endif; ?>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/utils/scripts.blade.php ENDPATH**/ ?>