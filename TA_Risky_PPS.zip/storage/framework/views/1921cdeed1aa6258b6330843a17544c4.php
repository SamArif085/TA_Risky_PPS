<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="font-weight-bold mb-0"><?php echo e($subtitle); ?></h4>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive pt-3">
                    
                    <table class="table table-bordered" id="data-table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Semester</th>
                                <th>Status Kehadiran</th>
                                <th>Waktu Masuk</th>
                                <th>Matkul</th>
                                <th>Kode Matkul</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item['tanggal']); ?></td>
                                <td><?php echo e($item['semester']); ?></td>
                                <td><?php echo e($item['status_kehadiran']); ?></td>
                                <td><?php echo e($item['waktu_masuk']); ?></td>
                                <td><?php echo e($item['matkul']['mata_kuliah']); ?></td>
                                <td><?php echo e($item['kode_matkul']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/admin/page/riwayat_presensi/index.blade.php ENDPATH**/ ?>