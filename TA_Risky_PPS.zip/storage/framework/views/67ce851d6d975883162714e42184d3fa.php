<div class="container-fluid page-header py-6 my-6 mt-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center">
        <h1 class="display-4 text-white animated slideInDown mb-4"><?php echo e(isset($title) ? $title : ''); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                <li class="breadcrumb-item text-primary active" aria-current="page"><?php echo e(isset($title) ? $title : ''); ?>

                </li>
            </ol>
        </nav>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-12">
            <center>
                <h4>Kegiatan PKM</h4>
            </center>
            <div class="card">
                <div class="card-header">Pengertian</div>
                <div class="card-body">
                    <p>
                        Pengabdian Masyarakat merupakan suatu media yang menghubungkan dunia pendidikan dengan
                        Masyarakat sekitar. Politeknik Penerbangan Surabaya akan memberikan kegiatan berupa
                        pelatihan kepada masyarakat sebagai bentuk hilirisasi pengajaran beberapa matakuliah yang dapat
                        dirasakan manfaatnya oleh Masyarakat disekitar kampus.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-12">
            <center>
                <h4>Daftar Kegiatan PKM</h4>
            </center>
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <?php $__currentLoopData = $kegiatanByTahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun => $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="tab-<?php echo e($tahun); ?>"
                        data-bs-toggle="tab" data-bs-target="#content-<?php echo e($tahun); ?>" type="button" role="tab"
                        aria-controls="content-<?php echo e($tahun); ?>" aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"><?php echo e($tahun); ?></button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabContent">
                <?php $__currentLoopData = $kegiatanByTahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun => $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="content-<?php echo e($tahun); ?>"
                    role="tabpanel" aria-labelledby="tab-<?php echo e($tahun); ?>">
                    <div class="accordion" id="accordion-<?php echo e($tahun); ?>">
                        <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="heading-<?php echo e($tahun); ?>-<?php echo e($index); ?>">
                                <button class="accordion-button <?php echo e($index == 0 ? '' : 'collapsed'); ?>" type="button"
                                    data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo e($tahun); ?>-<?php echo e($index); ?>"
                                    aria-expanded="<?php echo e($index == 0 ? 'true' : 'false'); ?>"
                                    aria-controls="collapse-<?php echo e($tahun); ?>-<?php echo e($index); ?>">
                                    <?php echo e($item->nama); ?>

                                </button>
                            </h2>
                            <div id="collapse-<?php echo e($tahun); ?>-<?php echo e($index); ?>" class="accordion-collapse collapse"
                                aria-labelledby="heading-<?php echo e($tahun); ?>-<?php echo e($index); ?>"
                                data-bs-parent="#accordion-<?php echo e($tahun); ?>">
                                <div class="accordion-body">
                                    <div>
                                        <h4>Rincian Kegiatan</h4>
                                    </div>
                                    <p><?php echo e($item->rincian_kegiatan); ?></p>
                                    <?php if($item->foto->isNotEmpty()): ?>
                                    <div class="img-konten">
                                        <?php $__currentLoopData = $item->foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset($foto->gambar)); ?>" alt="Gambar Kegiatan"
                                            class="img-fluid small-img">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/user/page/pkm.blade.php ENDPATH**/ ?>