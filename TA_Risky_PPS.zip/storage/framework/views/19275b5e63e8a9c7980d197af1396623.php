<div class="container-fluid page-header py-6 my-6 mt-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center">
        <h1 class="display-4 text-white animated slideInDown mb-4"><?php echo e(isset($title) ? $title : ''); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                <li class="breadcrumb-item text-primary active" aria-current="page"><?php echo e(isset($title) ? $title : ''); ?>

                </li>
            </ol>
        </nav>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-12">
            <center>
                <h4>Laporan Tugas Akhir</h4>
            </center>
            <ul class="nav nav-tabs" id="myTabtugasTa" role="tablist">
                <?php
                $uniquetugasTa = $link->where('kategori', '!=', 2)->unique('angkatan');
                ?>
                <?php $__currentLoopData = $uniquetugasTa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tugasTA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="tugasTA-tab-<?php echo e($tugasTA->id); ?>"
                        data-bs-toggle="tab" data-bs-target="#tugasTA-panel-<?php echo e($tugasTA->angkatan); ?>" type="button" role="tab"
                        aria-controls="tugasTA-panel-<?php echo e($tugasTA->angkatan); ?>"
                        aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                        <?php echo e($tugasTA->Angkatan['angkatan']); ?>

                    </button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabtugasTaContent">
                <?php $__currentLoopData = $uniquetugasTa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tugasTA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="tugasTA-panel-<?php echo e($tugasTA->angkatan); ?>"
                    role="tabpanel" aria-labelledby="tugasTA-tab-<?php echo e($tugasTA->id); ?>">
                    <div class="accordion" id="tugasTA-accordion-<?php echo e($tugasTA->angkatan); ?>">
                        <?php $__currentLoopData = $link->where('angkatan', $tugasTA->angkatan)->where('kategori', '!=', 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Filter jurnal bukan ojt -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="tugasTA-heading-<?php echo e($jurnal->id); ?>">
                                <button class="accordion-button text-dark" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#tugasTA-collapse-<?php echo e($jurnal->id); ?>" aria-expanded="true"
                                    aria-controls="tugasTA-collapse-<?php echo e($jurnal->id); ?>">
                                    <?php echo e($jurnal->nama); ?> - <?php echo e($jurnal->judul); ?> - <?php echo e($jurnal->tahun); ?>

                                </button>
                            </h2>
                            <div id="tugasTA-collapse-<?php echo e($jurnal->id); ?>" class="accordion-collapse collapse"
                                aria-labelledby="tugasTA-heading-<?php echo e($jurnal->id); ?>"
                                data-bs-parent="#tugasTA-accordion-<?php echo e($tugasTA->angkatan); ?>">
                                <div class="accordion-body">
                                    <strong><a href="<?php echo e($jurnal->file); ?>" target="_blank">Open Link</a></strong>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <center>
                <h4>Laporan OJT</h4>
            </center>
            <ul class="nav nav-tabs" id="myTabojt" role="tablist">
                <?php
                $uniqueojt = $link->where('kategori', 2)->unique('angkatan'); // Menggunakan 'angkatan' sebagai kriteria unik
                ?>
                <?php $__currentLoopData = $uniqueojt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ojt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="ojt-tab-<?php echo e($ojt->id); ?>"
                        data-bs-toggle="tab" data-bs-target="#ojt-panel-<?php echo e($ojt->angkatan); ?>" type="button" role="tab"
                        aria-controls="ojt-panel-<?php echo e($ojt->angkatan); ?>"
                        aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                        <?php echo e($ojt->Angkatan['angkatan']); ?>

                    </button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabojtContent">
                <?php $__currentLoopData = $uniqueojt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ojt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="ojt-panel-<?php echo e($ojt->angkatan); ?>"
                    role="tabpanel" aria-labelledby="ojt-tab-<?php echo e($ojt->id); ?>">
                    <div class="accordion" id="ojt-accordion-<?php echo e($ojt->angkatan); ?>">
                        <?php $__currentLoopData = $link->where('angkatan', $ojt->angkatan)->where('kategori', 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Filter hanya jurnal ojt -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="ojt-heading-<?php echo e($jurnal->id); ?>">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#ojt-collapse-<?php echo e($jurnal->id); ?>" aria-expanded="true"
                                    aria-controls="ojt-collapse-<?php echo e($jurnal->id); ?>">
                                    <?php echo e($jurnal->nama); ?> - <?php echo e($jurnal->judul); ?> - <?php echo e($jurnal->tahun); ?>

                                </button>
                            </h2>
                            <div id="ojt-collapse-<?php echo e($jurnal->id); ?>" class="accordion-collapse collapse"
                                aria-labelledby="ojt-heading-<?php echo e($jurnal->id); ?>"
                                data-bs-parent="#ojt-accordion-<?php echo e($ojt->angkatan); ?>">
                                <div class="accordion-body">
                                    <strong><a href="<?php echo e($jurnal->file); ?>" target="_blank">Open Link</a></strong>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/user/page/laporan_ta_ojt.blade.php ENDPATH**/ ?>