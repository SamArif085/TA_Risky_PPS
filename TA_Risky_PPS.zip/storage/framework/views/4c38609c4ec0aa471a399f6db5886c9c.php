<div class="container-fluid page-header py-6 my-6 mt-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center">
        <h1 class="display-4 text-white animated slideInDown mb-4"><?php echo e(isset($title) ? $title : ''); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                <li class="breadcrumb-item text-primary active" aria-current="page"><?php echo e(isset($title) ? $title : ''); ?>

                </li>
            </ol>
        </nav>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-12">
            <center>
                <h1>Kalender Pendidikan Program Studi TNU</h1>
            </center>
            <div class="accordion" id="accordionExample">
                <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angkatan => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="heading-<?php echo e($angkatan); ?>">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapse-<?php echo e($angkatan); ?>" aria-expanded="false"
                            aria-controls="collapse-<?php echo e($angkatan); ?>">
                            PROGRAM DIPLOMA IV TEKNIK NAVIGASI UDARA <?php echo e($group['name']); ?>

                        </button>
                    </h2>
                    <div id="collapse-<?php echo e($angkatan); ?>" class="accordion-collapse collapse"
                        aria-labelledby="heading-<?php echo e($angkatan); ?>" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <div>
                                <h2 class="text-center">Kalender Akademik</h2>
                                <h4 class="text-center">Tahun Ajaran <?php echo e($group['tahun']); ?></h4>
                            </div>
                            <div class="mb-5 mt-3">
                                <div class=""
                                    style="border: 1px solid #ddd; padding: 5px; background-color: #f2f2f2; margin-bottom: -1px;">
                                    <h5 class="text-center mt-1">Semester GANJIL <?php echo e($group['tahun']); ?> (<?php echo e($group['semesterGanjil']); ?>)</h5>
                                </div>
                                <table class="table table-bordered">
                                    <thead class="text-center">
                                        <tr>
                                            <th scope="col" rowspan="2">No</th>
                                            <th scope="col" rowspan="2">Kegiatan</th>
                                            <th scope="col" colspan="2">Jadwal Pelaksanaan</th>
                                        </tr>
                                        <tr>
                                            <th>Awal</th>
                                            <th>Akhir</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $semesterDisplayedGanjil = false; ?>
                                        <?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item['item']->ganjil_genap == 1): ?>
                                        <?php if(!$semesterDisplayedGanjil): ?>
                                        <?php $semesterDisplayedGanjil = true; ?>
                                        <?php endif; ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item['item']->kegiatan); ?></td>
                                            <td class="text-center"><?php echo e($item['item']->tgl_jadwal_awal); ?></td>
                                            <td class="text-center"><?php echo e($item['item']->tgl_jadwal_akhir); ?></td>
                                        </tr>
                                        <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div>
                                    <?php echo nl2br(e($group['catatansemesterGanjil'])); ?>

                                </div>
                            </div>
                            <div class="mb-5 mt-3">
                                <div class=""
                                    style="border: 1px solid #ddd; padding: 5px; background-color: #f2f2f2; margin-bottom: -1px;">
                                    <h5 class="text-center mt-1">Semester GENAP <?php echo e($group['tahun']); ?> (<?php echo e($group['semesterGenap']); ?>)</h5>
                                </div>
                                <table class="table table-bordered">
                                    <thead class="text-center">
                                        <tr>
                                            <th scope="col" rowspan="2">No</th>
                                            <th scope="col" rowspan="2">Kegiatan</th>
                                            <th scope="col" colspan="2">Jadwal Pelaksanaan</th>
                                        </tr>
                                        <tr>
                                            <th>Awal</th>
                                            <th>Akhir</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $semesterDisplayedGenap = false; $genapCounter = 0; ?>
                                        <?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item['item']->ganjil_genap == 2): ?>
                                        <?php if(!$semesterDisplayedGenap): ?>
                                        <?php $semesterDisplayedGenap = true; ?>
                                        <?php endif; ?>
                                        <tr>
                                            <td class="text-center"><?php echo e(++$genapCounter); ?></td>
                                            <td><?php echo e($item['item']->kegiatan); ?></td>
                                            <td class="text-center"><?php echo e($item['item']->tgl_jadwal_awal); ?></td>
                                            <td class="text-center"><?php echo e($item['item']->tgl_jadwal_akhir); ?></td>
                                        </tr>
                                        <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div>
                                    <?php echo nl2br(e($group['catatansemesterGenap'])); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/user/page/kalender.blade.php ENDPATH**/ ?>