<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(isset($title) ? $title : ''); ?></title>
    <!-- plugins: template css -->
    <link rel="stylesheet" href="<?php echo e(asset('template-admin/vendors/ti-icons/css/themify-icons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('template-admin/vendors/base/vendor.bundle.base.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('template-admin/css/style.css')); ?>" />
    <link rel="shortcut icon" href="<?php echo e(asset('template-admin/images/favicon.png')); ?>" />
    <?php echo $__env->make('utils.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <div class="container-scroller">
        <?php echo $__env->make('admin.template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid page-body-wrapper">
            <?php echo $__env->make('admin.template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-panel">
                <div class="content-wrapper">
                    <?php echo isset($konten) ? $konten : ''; ?>

                </div>
                <?php echo $__env->make('admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</body>

</html>
<?php echo $__env->make('utils.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('template-admin/vendors/base/vendor.bundle.base.js')); ?>"></script>
<script src="<?php echo e(asset('template-admin/vendors/chart.js/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('template-admin/js/off-canvas.js')); ?>"></script>
<script src="<?php echo e(asset('template-admin/js/hoverable-collapse.js')); ?>"></script>
<script src="<?php echo e(asset('template-admin/js/template.js')); ?>"></script>
<script src="<?php echo e(asset('template-admin/js/todolist.js')); ?>"></script>
<script src="<?php echo e(asset('template-admin/js/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('boostrap/bootstrap.js')); ?>"></script>

<script src="<?php echo e(isset($js) ? $js : ''); ?>"></script>
<script src="<?php echo e(asset('utils/datatable/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('utils/datatable/dataTables.bootstrap4.min.js')); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/admin/template/main.blade.php ENDPATH**/ ?>