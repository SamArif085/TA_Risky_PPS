<div class="col-lg-12">
    <div class="card">
        <div class="card-body mt-2">
            <table class="table datatable">
                <thead>
                    <tr>
                        <th>Nama Pencipta</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <td></td>
                    </tr>

                </tbody>
            </table>
            <div class="mb-3 float-end">
                
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/admin/page/profile/sejarah/index.blade.php ENDPATH**/ ?>