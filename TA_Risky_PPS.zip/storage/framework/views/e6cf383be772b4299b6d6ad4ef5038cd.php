<div class="container-fluid page-header py-6 my-6 mt-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center">
        <h1 class="display-4 text-white animated slideInDown mb-4"><?php echo e($title); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                <li class="breadcrumb-item text-primary active" aria-current="page"><?php echo e($title); ?></li>
            </ol>
        </nav>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-3">
            <div class="list-group" id="list-tab" role="tablist">
                <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="list-group-item list-group-item-action <?php echo e($key == 0 ? 'active' : ''); ?>"
                    id="list-<?php echo e($item['id']); ?>-list" data-bs-toggle="list" href="#list-<?php echo e($item['id']); ?>"
                    role="tab" aria-controls="list-<?php echo e($item['id']); ?>"><?php echo e($item['nama']); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-9">
            <div class="tab-content" id="nav-tabContent">
                <?php $__currentLoopData = $link; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($key == 0 ? 'show active' : ''); ?>" id="list-<?php echo e($item['id']); ?>"
                    role="tabpanel" aria-labelledby="list-<?php echo e($item['id']); ?>-list">
                    <h4><?php echo e($item['nama']); ?></h4>
                    <p><?php echo e($item['keterangan']); ?></p>
                    <img src="<?php echo e(asset($item['file'])); ?>" alt="Gambar Akreditasi" class="img-fluid">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/user/page/akreditasi.blade.php ENDPATH**/ ?>