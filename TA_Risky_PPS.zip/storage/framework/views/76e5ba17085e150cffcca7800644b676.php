<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item mb-3">
            <a class="nav-link" href="<?php echo e(url('dashboard')); ?>">
                <i class="ti-shield menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <?php if(Auth::user()->role == 3): ?>
        <p class="mx-2">List Menu</p>
        <li class="nav-item mb-3">
            <a class="nav-link" data-toggle="collapse" href="#menu-master" aria-expanded="false"
                aria-controls="menu-master">
                <i class="ti-palette menu-icon"></i>
                <span class="menu-title">Akses</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="menu-master">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('matkul_mhs',Auth::user()->id)); ?>">
                            <span class="menu-title">Matkul</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('riwayat-presensi', Auth::user()->id)); ?>">
                            <span class="menu-title">Riwayat Presensi</span>
                        </a>
                    </li>
                </ul>
            </div>
        </li>
        <?php endif; ?>
        <?php if(Auth::user()->role == 1): ?>
        <p class="mx-2">Master</p>
        <li class="nav-item mb-3">
            <a class="nav-link" data-toggle="collapse" href="#menu-master" aria-expanded="false"
                aria-controls="menu-master">
                <i class="ti-palette menu-icon"></i>
                <span class="menu-title">Master Menu</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="menu-master">
                <ul class="nav flex-column sub-menu">
                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('semester')); ?>">
                            <span class="menu-title">Semester</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('angkatan')); ?>">
                            <span class="menu-title">Angkatan</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('dosen')); ?>">
                            <span class="menu-title">Dosen</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('jenisDosen')); ?>">
                            <span class="menu-title">Jenis Dosen</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('masterAkademik')); ?>">
                            <span class="menu-title">Master Akademik</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('tahunKegiatan')); ?>">
                            <span class="menu-title">Tahun Kegiatan</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('jenisJurnal')); ?>">
                            <span class="menu-title">Jenis Jurnal</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('kegiatan-prodi')); ?>">
                            <span class="menu-title">Kegiatan Prodi</span>
                        </a>
                    </li>
                </ul>
            </div>
        </li>
        <p class="mx-2">Landing Page</p>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#menu1" aria-expanded="false" aria-controls="menu1">
                <i class="ti-palette menu-icon"></i>
                <span class="menu-title">Profile</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="menu1">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('akreditasi')); ?>">
                            <span class="menu-title">Akreditasi</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('sertifikasi')); ?>">
                            <span class="menu-title">Sertifikasi</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('video-profile')); ?>">Video Profile</a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#menu2" aria-expanded="false" aria-controls="menu2">
                <i class="ti-palette menu-icon"></i>
                <span class="menu-title">Akademik</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="menu2">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('akademik/kurikulum')); ?>">Kurikulum</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('akademik/kalender')); ?>">Kalender</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('akademik/staff-pengajar')); ?>">Staff Pengajar</a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#menu3" aria-expanded="false" aria-controls="menu3">
                <i class="ti-palette menu-icon"></i>
                <span class="menu-title">Fasilitas</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="menu3">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('laboratorium')); ?>">Laboratorium</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('kelas')); ?>">Kelas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('penunjang')); ?>">Fasilitas Penunjang</a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#menu4" aria-expanded="false" aria-controls="menu4">
                <i class="ti-palette menu-icon"></i>
                <span class="menu-title">Ketarunaan</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="menu4">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('ketarunaan/data-taruna')); ?>">Data Taruna</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('ketarunaan/prestasi')); ?>">Prestasi</a>
                    </li>
                    
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#menu5" aria-expanded="false" aria-controls="menu5">
                <i class="ti-palette menu-icon"></i>
                <span class="menu-title">Research</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="menu5">
                <ul class="nav flex-column sub-menu">
                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('laporan/TA-OJT')); ?>">Laporan Tugas Akhir <br> & OJT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('pengabdian/masyarakat')); ?>">Pengabdian Kepada <br>
                            Masyarakat</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('publikasi/ilmiah')); ?>">Publikasi Ilmiah</a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#menu5" aria-expanded="false" aria-controls="menu5">
                <i class="ti-palette menu-icon"></i>
                <span class="menu-title">Research</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="menu5">
                <ul class="nav flex-column sub-menu">
                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('laporan/TA-OJT')); ?>">Laporan Tugas Akhir <br> & OJT</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('pengabdian/masyarakat')); ?>">Pengabdian Kepada <br>
                            Masyarakat</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('publikasi/ilmiah')); ?>">Publikasi Ilmiah</a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#menu6" aria-expanded="false" aria-controls="menu6">
                <i class="ti-palette menu-icon"></i>
                <span class="menu-title">Setting Matkul</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="menu6">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('pengambilan_mata_kuliah_mhs')); ?>">Untuk Mahasiswa </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('pengambilan_mata_kuliah_dos')); ?>">Untuk Dosen</a>
                    </li>
                </ul>
            </div>
        </li>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/admin/template/sidebar.blade.php ENDPATH**/ ?>