<div class="container-fluid page-header py-6 my-6 mt-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center">
        <h1 class="display-4 text-white animated slideInDown mb-4"><?php echo e($title); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                <li class="breadcrumb-item"><a class="text-white" href="#">Pages</a></li>
                <li class="breadcrumb-item text-primary active" aria-current="page"><?php echo e($title); ?></li>
            </ol>
        </nav>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-12">
            <center>
                <h4>JURNAL DOSEN</h4>
            </center>
            <ul class="nav nav-tabs" id="myTabDosen" role="tablist">
                <?php
                $uniqueDosen = $link->where('id_jenis_jurnal', '!=', 2)->unique('nama'); // Filter jurnal bukan taruna
                ?>
                <?php $__currentLoopData = $uniqueDosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="dosen-tab-<?php echo e($dosen->id); ?>"
                        data-bs-toggle="tab" data-bs-target="#dosen-panel-<?php echo e($dosen->id); ?>" type="button" role="tab"
                        aria-controls="dosen-panel-<?php echo e($dosen->id); ?>"
                        aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                        <?php echo e($dosen->nama); ?>

                    </button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabDosenContent">
                <?php $__currentLoopData = $uniqueDosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="dosen-panel-<?php echo e($dosen->id); ?>"
                    role="tabpanel" aria-labelledby="dosen-tab-<?php echo e($dosen->id); ?>">
                    <div class="accordion" id="dosen-accordion-<?php echo e($dosen->id); ?>">
                        <?php $__currentLoopData = $link->where('nama', $dosen->nama)->where('id_jenis_jurnal', '!=', 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Filter jurnal bukan taruna -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="dosen-heading-<?php echo e($jurnal->id); ?>">
                                <button class="accordion-button text-dark" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#dosen-collapse-<?php echo e($jurnal->id); ?>" aria-expanded="true"
                                    aria-controls="dosen-collapse-<?php echo e($jurnal->id); ?>">
                                    <?php echo e($jurnal->judul_jurnal); ?>

                                </button>
                            </h2>
                            <div id="dosen-collapse-<?php echo e($jurnal->id); ?>" class="accordion-collapse collapse"
                                aria-labelledby="dosen-heading-<?php echo e($jurnal->id); ?>"
                                data-bs-parent="#dosen-accordion-<?php echo e($dosen->id); ?>">
                                <div class="accordion-body">
                                    <strong><a href="<?php echo e($jurnal->link_jurnal); ?>" target="_blank">Open Link</a></strong>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="row">
        <div class="col-12">
            <center>
                <h4>JURNAL TARUNA</h4>
            </center>
            <ul class="nav nav-tabs" id="myTabTaruna" role="tablist">
                <?php
                $uniqueTaruna = $link->where('id_jenis_jurnal', 2)->unique('nama'); // Filter hanya jurnal taruna
                ?>
                <?php $__currentLoopData = $uniqueTaruna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taruna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="taruna-tab-<?php echo e($taruna->id); ?>"
                        data-bs-toggle="tab" data-bs-target="#taruna-panel-<?php echo e($taruna->id); ?>" type="button" role="tab"
                        aria-controls="taruna-panel-<?php echo e($taruna->id); ?>"
                        aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                        <?php echo e($taruna->nama); ?>

                    </button>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabTarunaContent">
                <?php $__currentLoopData = $uniqueTaruna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taruna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="taruna-panel-<?php echo e($taruna->id); ?>"
                    role="tabpanel" aria-labelledby="taruna-tab-<?php echo e($taruna->id); ?>">
                    <div class="accordion" id="taruna-accordion-<?php echo e($taruna->id); ?>">
                        <?php $__currentLoopData = $link->where('nama', $taruna->nama)->where('id_jenis_jurnal', 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Filter hanya jurnal taruna -->
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="taruna-heading-<?php echo e($jurnal->id); ?>">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#taruna-collapse-<?php echo e($jurnal->id); ?>" aria-expanded="true"
                                    aria-controls="taruna-collapse-<?php echo e($jurnal->id); ?>">
                                    <?php echo e($jurnal->judul_jurnal); ?>

                                </button>
                            </h2>
                            <div id="taruna-collapse-<?php echo e($jurnal->id); ?>" class="accordion-collapse collapse"
                                aria-labelledby="taruna-heading-<?php echo e($jurnal->id); ?>"
                                data-bs-parent="#taruna-accordion-<?php echo e($taruna->id); ?>">
                                <div class="accordion-body">
                                    <strong><a href="<?php echo e($jurnal->link_jurnal); ?>" target="_blank">Open Link</a></strong>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Kuliah\PENS\MatkulPens\TA\HKI\TA_Risky_PPS\resources\views/user/page/jurnal.blade.php ENDPATH**/ ?>